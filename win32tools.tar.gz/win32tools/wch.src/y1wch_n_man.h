#ifndef Y1WCH_N_MAN_HHHH
#define Y1WCH_N_MAN_HHHH

#include  <stdio.h>
#include  <signal.h>

#define   DEBUG   0

unsigned char *buf, *outbufwww;
unsigned char ch_table[65536];
unsigned char *bufwww, *outbuf;
#define MAX_CH_TABLE_W 65536
int giKbigchno;
int iNch_table_w;
unsigned int ulCh_table_w[MAX_CH_TABLE_W];

#endif
