#ifndef Y0MKUTIL_MAN_HHH
#define Y0MKUTIL_MAN_HHH
#include <stdio.h>
#include <y0wadd_prot.h>


#endif
