#include <stdlib.h>
void ctrlc(int iii) {
    exit(0);
}
