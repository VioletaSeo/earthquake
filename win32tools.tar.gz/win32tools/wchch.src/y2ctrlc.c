#include <y2wchch_man.h>
#include <y2wchch_prot.h>
#include <stdlib.h>
void ctrlc(int iii) {
    exit(1);
}
